Anleitung zur lokalen Nutzung (Voraussetzung: Node.js installiert)

1. ZIP-Datei entpacken
2. In den entpackten Ordner wechseln
3. Im Terminal ausführen:
   npm install express
4. Starte den Server mit:
   node server.js
5. Öffne im Browser:
   http://localhost:3000/index.html  → Bestellseite
   http://localhost:3000/admin.html  → Küchenansicht (PIN: 8857)